package com.sat.Pages;


import static org.testng.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;


import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import com.sat.testUtil.Assertions;
import com.sat.testUtil.Log;
import com.sat.testUtil.Testutil;
import com.sat.testUtil.Wait;
import com.sat.testbase.TestBase;

import io.cucumber.datatable.DataTable;

public class ETCase_ET {

	WebDriver driver = TestBase.getDriver();
	TestBase testbase = new TestBase();
	Testutil testutil = new Testutil(driver);
	Actions action = new Actions(driver);
	WebDriverWait wait = new WebDriverWait(driver, 20);
	String listofvalues;
	SLATimer slatimer = new SLATimer(driver);
	Optimization omptimization = new Optimization(driver);
	Assertions assertion = new Assertions(driver);
	
	public ETCase_ET(WebDriver driver) {
		this.driver = driver;
	}
	
	public void enterDetailsWorkPlacementOutcomeSection()
	{
		testutil.sendKeys(driver, driver.findElement(By.xpath("//input[@aria-label='Work Placement Company']")), 10, "WorkPlacement");
		//testutil.inputText(driver, "Work Placement Company", 10, "WorkPlacement");
		
	}
	
	public void enterDetailsVolunteeringsection()
	{
		testutil.sendKeys(driver, driver.findElement(By.xpath("//input[@aria-label='Volunteering Company']")), 10, "VolunteeringCompany");
		//testutil.inputText(driver, "Volunteering Company", 10, "VolunteeringCompany");

	}
	
	public void checkGrid(String string , String s)
	{
		try {
			Thread.sleep(2000);

//			actions.click(
//					driver.findElement(By.xpath("//section[@aria-label='" + string + "']//*[text()='Outcome Type']")))
//					.build().perform();
			
			action.click(
					driver.findElement(By.xpath("//section[@aria-label='" + string + "']//div[@aria-rowindex='1']//div[@aria-colindex='2']")))
					.build().perform();
			
			action.click(driver.findElement(By.xpath("//span[text()='Filter by']"))).build().perform();
			action.click(driver.findElement(By.xpath("//div[@aria-label='Filter by value']"))).build().perform();
			//action.sendKeys(null, null)
			//sendkeys(driver.findElement(By.xpath("//span[text()='" + s + "']"))).build().perform();
			action.click(driver.findElement(By.xpath("//span[text()='Apply']"))).build().perform();
			
			
			Thread.sleep(4000);
			Log.info(string + " grid values are " + driver
					.findElement(By.xpath("//section[@aria-label='" + string + "']")).getAttribute("textContent"));
			assertion.CheckAssertionTrue(driver.findElement(By.xpath("//section[@aria-label='" + string + "']"))
					.getAttribute("textContent").contains(s), s);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}