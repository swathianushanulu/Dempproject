package com.sat.StepDefinitions;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.sat.Pages.Assessment_ET;
import com.sat.Pages.CasePage;
import com.sat.Pages.ContactForm;
import com.sat.Pages.ETCase_ET;
import com.sat.Pages.GenericCases;
import com.sat.Pages.LoginPage;
import com.sat.Pages.Optimization;
import com.sat.Pages.Outcome_ET;
import com.sat.Pages.SLATimer;
import com.sat.testUtil.Assertions;
import com.sat.testUtil.Log;
import com.sat.testUtil.Testutil;
import com.sat.testUtil.Wait;
import com.sat.testbase.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

public class ETCase_ETStepDefs {

	TestBase testbase = new TestBase();
	WebDriver driver = TestBase.getDriver();
	LoginPage loginpage = new LoginPage(driver);
	Testutil testutil = new Testutil(driver);
	Assertions assertion = new Assertions(driver);
	Actions actions = new Actions(driver);
	Assessment_ET assessment_ET = new Assessment_ET(driver);
	SLATimer slatimer = new SLATimer(driver);
	private CasePage cases = new CasePage(driver);
	Optimization omptimization = new Optimization(driver);
	GenericCases genericCases = new GenericCases(driver);
	private ContactForm contact = new ContactForm(driver);
	HashMap<String, String> assessmentDetails = new HashMap<String, String>();
	HashMap<String, String> dates = new HashMap<String, String>();
	Outcome_ET outcome_et = new Outcome_ET(driver);
	ETCase_ET etCase_et = new ETCase_ET(driver);

	@Then("read the Assessment {string} details")
	public void read_the_Assessment_details(String string) {

		assessmentDetails.put("Assessment",
				driver.findElement(By.xpath("//h1[@data-id='header_title']")).getAttribute("title"));
		Log.info("Assessment Assessment is ::  " + assessmentDetails.get("Assessment"));

		assessmentDetails.put("ActionPlan", driver.findElement(By.xpath(
				"//ul[@data-id='po_action_planid.fieldControl-LookupResultsDropdown_po_action_planid_SelectedRecordList']"))
				.getAttribute("textContent"));
		Log.info("Assessment ActionPlan is ::  " + assessmentDetails.get("ActionPlan"));

		assessmentDetails.put("ETCase",
				driver.findElement(By.xpath(
						"//ul[@data-id='po_etcase.fieldControl-LookupResultsDropdown_po_etcase_SelectedRecordList']"))
						.getAttribute("textContent"));
		Log.info("Assessment ETCase is ::  " + assessmentDetails.get("ETCase"));

		testutil.clickOn(driver, driver.findElement(By.xpath("//button[@aria-label='More Header Fields']")), 10);

		assessmentDetails.put("ContactAssessed", driver.findElement(By.xpath(
				"//ul[@data-id ='header_po_contactassessed.fieldControl-LookupResultsDropdown_po_contactassessed_SelectedRecordList']"))
				.getAttribute("textContent"));
		Log.info("Assessment ContactAssessed is ::  " + assessmentDetails.get("ContactAssessed"));

		assessmentDetails.put("ModifiedBy", driver.findElement(By.xpath(
				"//ul[@data-id ='header_modifiedby.fieldControl-LookupResultsDropdown_modifiedby_SelectedRecordList']"))
				.getAttribute("textContent"));
		Log.info("Assessment ModifiedBy is ::  " + assessmentDetails.get("ModifiedBy"));

		assessmentDetails.put("ETO",
				driver.findElement(By.xpath(
						"//ul[@data-id ='header_po_eto.fieldControl-LookupResultsDropdown_po_eto_SelectedRecordList']"))
						.getAttribute("textContent"));
		Log.info("Assessment ETO is ::  " + assessmentDetails.get("ETO"));

		assessmentDetails.put("PersonReference",
				driver.findElement(
						By.xpath("//input[@data-id ='header_po_person_reference.fieldControl-text-box-text']"))
						.getAttribute("title"));
		Log.info("Assessment PersonReference is ::  " + assessmentDetails.get("PersonReference"));

		assessmentDetails.put("MobilePhone",
				driver.findElement(By.xpath("//input[@data-id ='header_po_mobilephone.fieldControl-text-box-text']"))
						.getAttribute("title"));
		Log.info("Assessment MobilePhone is ::  " + assessmentDetails.get("MobilePhone"));

		assessmentDetails.put("HomeNumber",
				driver.findElement(By.xpath("//input[@data-id ='header_po_homephone.fieldControl-text-box-text']"))
						.getAttribute("title"));
		Log.info("Assessment HomeNumber is ::  " + assessmentDetails.get("HomeNumber"));

		assessmentDetails.put("ReasonforEnrolment",
				driver.findElement(
						By.xpath("//select[@data-id ='header_po_reasonforenrolment.fieldControl-option-set-select']"))
						.getAttribute("title"));
		Log.info("Assessment ReasonforEnrolment is ::  " + assessmentDetails.get("ReasonforEnrolment"));

	}

	@Then("user validate the fields are mapped from Assessment")
	public void user_validate_the_fields_are_mapped_from_Assessment() {
		try {

			assertion.CheckAssertion(
					driver.findElement(By.xpath("//ul[contains(@data-id,'contact')]")).getAttribute("textContent"),
					assessmentDetails.get("ContactAssessed"));
			assertion.CheckAssertion(
					driver.findElement(By.xpath("//ul[contains(@data-id,'eto')]")).getAttribute("textContent"),
					assessmentDetails.get("ETO"));
			assertion.CheckAssertion(
					driver.findElement(By.xpath("//ul[contains(@data-id,'assessment')]")).getAttribute("textContent"),
					assessmentDetails.get("Assessment"));

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Then("user validate Action plan associated to the Assessment is showing in the Action Plan Grid")
	public void user_validate_Action_plan_associated_to_the_Assessment_is_showing_in_the() throws IOException {
		try {
			String Expected = driver.findElement(By.xpath("//div[contains(@data-lp-id,'po_actionplan')]"))
					.getAttribute("textContent");
			assertion.CheckAssertionTrue(Expected.contains(assessmentDetails.get("ActionPlan")), "Action Plan Grid");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Then("user validate the following grids are displayed")
	public void user_validate_the_following_grids_are_displayed(io.cucumber.datatable.DataTable dataTable) {
		try {
			List<String> actual = dataTable.asList();
			Log.info(" Size of the data table is : " + actual.size());
			for (int i = 0; i <= actual.size() - 1; i++) {
				Thread.sleep(4000);
				String expected = driver.findElement(By.xpath("//div[@aria-label='Outcomes']"))
						.getAttribute("outerText");
				Log.info(expected);
				Thread.sleep(2000);
				assertion.CheckAssertionTrue(expected.contains(actual.get(i)), actual.get(i));
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Then("user click on ET Case name {string}")
	public void user_click_on_ET_Case_name(String ETCase) {
		try {
			Thread.sleep(2000);
			testutil.jsclick(driver.findElement(By.xpath("//*[text()='" + ETCase + "']")), driver);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Then("user validate {string} grid exist with following fields")
	public void user_validate_grid_exist_with_following_fields(String string, DataTable dataTable) {
		try {
			List<String> actual = dataTable.asList();
			Log.info(" Size of the data table is : " + actual.size());
			Thread.sleep(2000);

			// Locating element by link text and store in variable "Element"
			WebElement Element = driver.findElement(By.xpath("//section[@aria-label='" + string + "']"));
			JavascriptExecutor js = (JavascriptExecutor) driver;

			for (int i = 0; i <= actual.size() - 1; i++) {
				String expected = driver.findElement(By.xpath("//div[@aria-label='Outcomes']"))
						.getAttribute("outerText");
				Log.info(expected);
				Thread.sleep(2000);
				// Scrolling down the page till the element is found
				js.executeScript("arguments[0].scrollIntoView();", Element);
				assertion.CheckAssertionTrue(expected.contains(actual.get(i)), actual.get(i));
				Thread.sleep(2000);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Then("user creates {string} as {string}")
	public void user_creates_as_and_validates_in_grid(String string, String string2) throws Exception 
	{
		try {
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor) driver;

			// Scrolling down the page till the element is found
			js.executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath("//section[contains(@aria-label,'" + string2 + "')]")));
			testutil.clickOn(driver,
					driver.findElement(
							By.xpath("//section[contains(@aria-label,'" + string2 + "')]//*[text()='New Outcome']")),
					10);
			Thread.sleep(2000);
			testutil.selectByVisibleText(driver, driver.findElement(By.xpath("//select[@aria-label='Outcome Type']")),
					string2);
			Thread.sleep(2000);
			Log.info(string2);

			if (string2.contains("Job")) {
				Log.info("executing job");
				dates = outcome_et.enterDetailsJobSection();
				outcome_et.enterDetailsRentAccountCaptureSection();
				outcome_et.EnterDetailSustainment_ChecksSection();
			}

			if (string2.contains("Training")) {
				Log.info("executing Training");
				outcome_et.EnterDetailsTrainingSection("Training Outcome");
			}

			if (string2.contains("Wellbeing")) {
				Log.info("executing Wellbeing");
				outcome_et.enterWellbeingSection();
			}

			if (string2.contains("Work Placement")) {
				Log.info("executing Wellbeing");
				etCase_et.enterDetailsWorkPlacementOutcomeSection();
			}

			if (string2.contains("Volunteering")) {
				Log.info("executing Wellbeing");
				etCase_et.enterDetailsVolunteeringsection();
			}

			Thread.sleep(4000);
			testutil.clickOn(driver, driver.findElement(By.xpath("//button[@aria-label='Save (CTRL+S)']")), 10);
			Thread.sleep(5000);			
			testutil.jsclick( driver.findElement(By.xpath("//button[@data-id='navigateBackButtontab-id-0']")),driver);
			Thread.sleep(4000);
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}	
	
	
	 @Then("user validates the Job Outcomes for {string}")
	 public void user_validates_the_grid_(String string) throws Exception
	 {
		 actions.click(
					driver.findElement(By.xpath("//section[@aria-label='Job Outcomes']//div[@aria-rowindex='1']//div[@aria-colindex='2']")))
					.build().perform();
			actions.click(driver.findElement(By.xpath("//span[text()='Filter by']"))).build().perform();
			actions.sendKeys(driver.findElement(By.xpath("//input[@aria-label='Filter by value']")),string).build().perform();
			Thread.sleep(2000);
			actions.click(driver.findElement(By.xpath("//span[text()='Apply']"))).build().perform();
			Thread.sleep(4000);
			Log.info(string + " grid values are " + driver
					.findElement(By.xpath("//section[@aria-label='Job Outcomes']")).getAttribute("textContent"));
			assertion.CheckAssertionTrue(driver.findElement(By.xpath("//section[@aria-label='Job Outcomes']"))
					.getAttribute("textContent").contains(string), string);
		 
	 }
	 
	    @Then("user validates the Work Placement for {string}")
	    public void user_validates_the_grid_Work_Placement(String string) throws Exception
	    {
	    	
	    	Thread.sleep(4000); 
	    	JavascriptExecutor js = (JavascriptExecutor) driver;

			// Scrolling down the page till the element is found
			js.executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath("//section[contains(@aria-label,'Work Placement Outcomes')]")));
	    	Thread.sleep(2000); 
	    	//testutil.jsclick(driver.findElement(By.xpath("//section[@aria-label='Work Placement Outcomes']//div[@aria-rowindex='1']//div[@aria-colindex='2']")), driver);
	    	actions.moveToElement(driver.findElement(By.xpath("//section[@aria-label='Work Placement Outcomes']//div[@aria-rowindex='1']//div[@aria-colindex='2']"))); 
	    	actions.click(
						driver.findElement(By.xpath("//section[@aria-label='Work Placement Outcomes']//div[@aria-rowindex='1']//div[@aria-colindex='2']")))
						.build().perform();
	    	Thread.sleep(2000);	
	    	actions.click(driver.findElement(By.xpath("//span[text()='Filter by']"))).build().perform();
	    	Thread.sleep(2000);	
	    	actions.sendKeys(driver.findElement(By.xpath("//input[@aria-label='Filter by value']")),string).build().perform();
				Thread.sleep(2000);
				actions.click(driver.findElement(By.xpath("//span[text()='Apply']"))).build().perform();
				Thread.sleep(2000);
				Log.info(string + " grid values are " + driver
						.findElement(By.xpath("//section[@aria-label='Work Placement Outcomes']")).getAttribute("textContent"));
				assertion.CheckAssertionTrue(driver.findElement(By.xpath("//section[@aria-label='Work Placement Outcomes']"))
						.getAttribute("textContent").contains(string), string);
	    }

	
        @Then("user validates the Volunteering Outcomes for {string}")
        public void user_validates_the_Volunteering_Outcomes(String string) throws Exception
        {
        	Thread.sleep(4000);
        	JavascriptExecutor js = (JavascriptExecutor) driver;

			// Scrolling down the page till the element is found
			js.executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath("//section[contains(@aria-label,'Volunteering Outcomes')]")));
	    	Thread.sleep(2000); 
	    	//testutil.jsclick(driver.findElement(By.xpath("//section[@aria-label='Work Placement Outcomes']//div[@aria-rowindex='1']//div[@aria-colindex='2']")), driver);
	    	actions.moveToElement(driver.findElement(By.xpath("//section[@aria-label='Volunteering Outcomes']//div[@aria-rowindex='1']//div[@aria-colindex='2']"))); 
	    	actions.click(
						driver.findElement(By.xpath("//section[@aria-label='Volunteering Outcomes']//div[@aria-rowindex='1']//div[@aria-colindex='2']")))
						.build().perform();
	    	Thread.sleep(2000);	
	    	actions.click(driver.findElement(By.xpath("//span[text()='Filter by']"))).build().perform();
	    	Thread.sleep(2000);	
	    	actions.sendKeys(driver.findElement(By.xpath("//input[@aria-label='Filter by value']")),string).build().perform();
				Thread.sleep(2000);
				actions.click(driver.findElement(By.xpath("//span[text()='Apply']"))).build().perform();
				Thread.sleep(2000);
				Log.info(string + " grid values are " + driver
						.findElement(By.xpath("//section[@aria-label='Volunteering Outcomes']")).getAttribute("textContent"));
				assertion.CheckAssertionTrue(driver.findElement(By.xpath("//section[@aria-label='Volunteering Outcomes']"))
						.getAttribute("textContent").contains(string), string);
        }

       @Then("user validates the Training Outcomes for {string}")
       public void user_validates_the_Training_Outcomes(String string) throws Exception
       {
    	   Thread.sleep(4000);
       	JavascriptExecutor js = (JavascriptExecutor) driver;

			// Scrolling down the page till the element is found
			js.executeScript("arguments[0].scrollIntoView();",
					driver.findElement(By.xpath("//section[contains(@aria-label,'Training Outcomes')]")));
	    	Thread.sleep(2000); 
	    	actions.moveToElement(driver.findElement(By.xpath("//section[@aria-label='Training Outcomes']//div[@aria-rowindex='1']//div[@aria-colindex='2']"))); 
	    	actions.click(
						driver.findElement(By.xpath("//section[@aria-label='Training Outcomes']//div[@aria-rowindex='1']//div[@aria-colindex='2']")))
						.build().perform();
	    	Thread.sleep(2000);	
	    	actions.click(driver.findElement(By.xpath("//span[text()='Filter by']"))).build().perform();
	    	Thread.sleep(2000);	
	    	actions.click(driver.findElement(By.xpath("//div[@aria-label='Filter by value']"))).build().perform();
	    	Thread.sleep(2000);	
	    	actions.click(driver.findElement(By.xpath("//span[text()='Accredited Training']"))).build().perform();
	    	Thread.sleep(2000);	
	    	actions.click(driver.findElement(By.xpath("//div[@aria-label='Filter by value']"))).build().perform();
	    	actions.click(driver.findElement(By.xpath("//span[text()='Apply']"))).build().perform();
	    	Thread.sleep(2000);
			Log.info(string + " grid values are " + driver
					.findElement(By.xpath("//section[@aria-label='Training Outcomes']")).getAttribute("textContent"));
			Thread.sleep(2000);
			assertion.CheckAssertionTrue(driver.findElement(By.xpath("//section[@aria-label='Training Outcomes']"))
					.getAttribute("textContent").contains(string), string);
		
       }

       @Then("user validate the message {string}")
       public void user_validate_the_message(String string) {
    	   
    	 String Expected = driver.findElement(By.xpath("//li[@aria-labelledby='message-formReadOnlyNotification']")).getAttribute("textContent");
    	  assertion.CheckAssertionTrue(Expected.contains(string), string);
    	       	   
         
       }

       @Then("user validate ET case Editable")
       public void user_validate_ET_case_Editable() {    	   
    	   assertion.CheckAssertionTrue(driver.findElement(By.xpath("//button[contains(@title,'Deactivate')]")).isDisplayed(), "Deactivate");
       }

       @Then("user validate the fields in ET Case Reason for Closure")
       public void user_validate_the_fields_in_ET_Case_Reason_for_Closure() {
        
       }
        

}
