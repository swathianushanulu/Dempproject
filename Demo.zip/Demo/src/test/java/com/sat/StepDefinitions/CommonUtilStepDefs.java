package com.sat.StepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.sat.Pages.CommonPages;
import com.sat.testUtil.Testutil;
import com.sat.testUtil.Wait;
import com.sat.testbase.TestBase;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CommonUtilStepDefs {

	WebDriver driver= TestBase.getDriver();
	TestBase testbase = new TestBase();
	public CommonPages common = new CommonPages(driver);
	Testutil testUtil = new Testutil(driver);
	public static String output = "";

//	public CommonUtilStepDefs(WebDriver driver) {
//		this.driver = driver;
//		}
	@Then("user selects {string} as {string}")
	public void user_selects_with(String label, String option) {
		common.selectLabelWithOption(label, option);
		Wait.untilPageLoadComplete(driver);
	}

	@When("user filters {string} as {string} with {string}")
	public void user_filters_with(String filter, String option, String filterOption) throws InterruptedException {
		user_selects_with(filter, option);
		common.selectFilterWithOption(filterOption);
	}
	

}
