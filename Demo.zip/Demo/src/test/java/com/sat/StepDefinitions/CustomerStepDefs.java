package com.sat.StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.sat.Pages.CasePage;
import com.sat.Pages.CustomerPage;
import com.sat.Pages.LoginPage;
import com.sat.testUtil.Testutil;
import com.sat.testUtil.Wait;
import com.sat.testbase.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CustomerStepDefs {

	TestBase testbase = new TestBase();
	WebDriver driver= TestBase.getDriver();

	private CustomerPage accountpage = new CustomerPage(driver);
	private CasePage cases = new CasePage(driver);

	Testutil testUtil = new Testutil(driver);

	@When("user click on {string} under customer")
	public void user_click_on_under_customer(String tab) {
		try {
			if (!driver.findElements(By.xpath("//button[@aria-label='Discard changes']")).isEmpty())
				driver.findElement(By.xpath("//button[@aria-label='Discard changes']")).click();
			Thread.sleep(2000);
			accountpage.entity(tab);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");}
	}

	@Then("user fill all the details for {string} as {string}")
	public void user_fill_all_the_details(String field, String value) throws InterruptedException {
		try {
		Wait.untilPageLoadComplete(driver,8);
		cases.fillDetails(field, value);
		if (value.contains("ASB")) {
			Wait.untilPageLoadComplete(driver,5);
			driver.findElement(By.cssSelector("body")).sendKeys(Keys.TAB, Keys.PAGE_DOWN);
			Wait.untilPageLoadComplete(driver,5);
			testUtil.jsclick(cases.Category("ASB Case Category"), driver);
			testUtil.selectByVisibleText(driver, cases.Category("ASB Case Category"), "Noise");
			Thread.sleep(2000);
			cases.Category("ASB Type").click();
			testUtil.selectByVisibleText(driver, cases.Category("ASB Type"), "Music");
			System.out.println("fille field = "+ field);
		}}
		catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");}
	}

	@When("user click on {string} under Service")
	public void user_click_on_under_service(String tab) {
		try {
			accountpage.entity(tab);
			Wait.untilPageLoadComplete(driver,5);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");

		}
	}

	@And("user verify left side pane under customer")
	public void user_verify_left_side_pane_under_customer() throws InterruptedException {
		try {
			accountpage.verifyleftsidepane();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");

		}
	}

	@And("user click on Drop Down List")
	public void user_click_on_drop_Down_List() {
		try {
			accountpage.clickonDropdownList();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@And("user click on Case Drop Down List")
	public void user_click_on_Casedrop_Down_List() {
		try {
			accountpage.clickonCaseDropdownList();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");

		}
	}

	@And("user select {string} from drop down list")
	public void user_select_from_drop_down_list(String option) throws InterruptedException {
		try {
		accountpage.clickonAllAccount(option);
		Wait.untilPageLoadComplete(driver,5);
		Thread.sleep(2000);
		// driver.findElement(By.xpath("//*[text()='"+option+"']")).click();
		}
		catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");}
	}

	@And("user select {string} from drop down")
	public void user_select_from_drop_down(String option) throws InterruptedException {
		try {
			accountpage.clickonQueue(option);
			Wait.untilPageLoadComplete(driver,5);
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");

		}
	}

	@When("user select a queue filter {string}")
	public void user_select_a_queue_filter(String filter) throws InterruptedException {
		try {
			accountpage.selectQueueFilter(filter);
			Wait.untilPageLoadComplete(driver,5);
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");

		}
	}

	@Then("user enter {string} in search text box and validate text")
	public void user_enter_text_in_search_text_box(String SearchText) throws InterruptedException {
		try {
			accountpage.Entertextinsearch(SearchText);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");

		}

	}

	@Then("user enter {string} in global search text box and validate text")
	public void user_enter_text_in_global_search_text_box(String SearchText) throws InterruptedException {
		try {
			accountpage.enterTextInGlobalSearch(SearchText);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");

		}

	}

	@And("user click on search icon")
	public void user_click_on_search_icon() {
		try {
			accountpage.clickonsearchicon();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");

		}

	}

	@Then("search result is display{string}")
	public void search_result_is_display(String searchtext) {
		try {
			accountpage.verifysearchresult(searchtext);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");

		}

	}

	@Then("user click on Blocks entity and verify local search")
	public void user_click_on_Blocks_entity_and_verify_local_search(DataTable dataTable) throws InterruptedException {
		try {
		driver.findElement(By.xpath("//div[@title='Blocks']")).click();
		Thread.sleep(2000);
		accountpage.localSearch(dataTable);}
		catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");}
	}

	@Then("user click on Neighborhoods entity and verify local search")
	public void user_click_on_Neighborhoods_entity_and_verify_local_search(DataTable dataTable)
			throws InterruptedException {
		try {
		driver.findElement(By.xpath("//div[@title='Neighborhoods']")).click();
		Thread.sleep(2000);
		accountpage.localSearch(dataTable);}
		catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");}
	}

	@Then("user click on Schemes entity and verify local search")
	public void user_click_on_Schemes_entity_and_verify_local_search(DataTable dataTable) throws InterruptedException {
		try {
		driver.findElement(By.xpath("//div[@title='Schemes']")).click();
		Thread.sleep(2000);
		accountpage.localSearch(dataTable);}
		catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");}

	}

	@Then("user click on Contacts entity and verify local search")
	public void user_click_on_Contacts_entity_and_verify_local_search(DataTable dataTable) throws InterruptedException {
		try {
		driver.findElement(By.xpath("//div[@title='Contacts']")).click();
		Thread.sleep(2000);
		accountpage.clickonDropdownList();
		driver.findElement(By.xpath("//*[text()='All Contacts']")).click();
		Thread.sleep(2000);
		accountpage.localSearch(dataTable);}
		catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");}
	}

	@Then("user click on Data Protection entity and verify local search")
	public void user_click_on_Data_Protection_entity_and_verify_local_search(DataTable dataTable)
			throws InterruptedException {
		try {
		driver.findElement(By.xpath("//div[@title='Data Protection']")).click();
		Thread.sleep(2000);
		accountpage.localSearch(dataTable);}
		catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");}
	}

	@Then("user click on Tenancies and verify local search")
	public void user_click_on_Tenancies_and_verify_local_search(DataTable dataTable) throws InterruptedException {
		try {
		driver.findElement(By.xpath("//div[@title='Tenancies']")).click();
		Thread.sleep(2000);
		accountpage.localSearch(dataTable);}
		catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");}
	}

	@Then("user click on Knowledge Articles and verify local search")
	public void user_click_on_Knowledge_Articles_and_verify_local_search(DataTable dataTable) {

	}

}
