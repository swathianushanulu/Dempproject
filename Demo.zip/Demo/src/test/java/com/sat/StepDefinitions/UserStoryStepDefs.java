package com.sat.StepDefinitions;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.sat.Pages.UserStory;
import com.sat.testUtil.Assertions;
import com.sat.testUtil.Testutil;
import com.sat.testUtil.Wait;
import com.sat.testbase.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;

public class UserStoryStepDefs {
	WebDriver driver= TestBase.getDriver();
	TestBase testbase = new TestBase();
	UserStory userStory = new UserStory(driver);
	Testutil testUtil = new Testutil(driver);
	Assertions assertion = new Assertions(driver);
	
	@Then("user verify {string} filed is Locked")
	public void user_verify_filed_is_Locked(String string) {
		String actual=userStory.validateLockedField(string);
		System.out.println("Locked Field : "+actual);
		assertion.CheckAssertionTrue(actual.contains("Locked"),"");
		
	}
	@Then("user verify all the {string} list values")
	public void user_verify_all_the_list_value(String field, DataTable dataTable) {
		try {
			List<String> actual = dataTable.asList();
			String expected = userStory.validateListValue(field);
			System.out.println("Expected : "+expected);
			// String[] arrlstValues = listofvalues.split("\\n");
			System.out.println(actual.size());
			for (int i = 0; i <= actual.size() - 1; i++) {
				// System.out.println(actual.get(i));
				System.out.println("Actual : "+actual.get(i));
				Wait.untilPageLoadComplete(driver,500);
				Assert.assertTrue(expected.contains(actual.get(i)));
				Wait.untilPageLoadComplete(driver,200);
			}}
			catch (AssertionError e) {
		         System.out.println(e.getMessage());
		      }
	}
	@Then("user validate Originating Neighbourhood fields is auto populated")
	public void user_validate_Originating_Neighbourhood_fields_is_auto_populated()
	{
		userStory.validateAutoPopulatedField();
	}
	


	@Then("user verify the new values as {string} and {string} in {string}")
	public void user_verify_the_and(String string, String string2,String string3) {
		
		try {
			Thread.sleep(5000);
			driver.switchTo().frame(driver.findElement(By.xpath("//*[@id='audit_iframe']")));
			String expected = driver.findElement(By.xpath("//*[@role='row' and @otypename ='audit' ][1]/td[7]")).getAttribute("textContent");
	
			//walkabouts
			assertion.CheckAssertionTrue(expected.contains(string), string);

			//rating
			assertion.CheckAssertionTrue(expected.contains(string2), string2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	@Then("user validate {string} field as {string}")
	public void user_validate_field_as(String string, String string2) throws IOException {
		String expected = driver.findElement(By.xpath("//input[@aria-label='Date of Walkabout Completion Date']")).getAttribute("defaultValue");
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String currentdate = sdf.format(new Date());
        assertion.CheckAssertion(expected, currentdate);
	}

}
