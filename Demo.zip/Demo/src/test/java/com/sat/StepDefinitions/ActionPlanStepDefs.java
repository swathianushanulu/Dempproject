package com.sat.StepDefinitions;

import java.awt.Desktop.Action;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.sat.Pages.CasePage;
import com.sat.Pages.CustomerPage;
import com.sat.testUtil.Assertions;
import com.sat.testUtil.Log;
import com.sat.testUtil.Testutil;
import com.sat.testUtil.Wait;
import com.sat.testbase.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ActionPlanStepDefs {

	TestBase testbase = new TestBase();
	WebDriver driver = TestBase.getDriver();

	private CustomerPage accountpage = new CustomerPage(driver);
	private CasePage cases = new CasePage(driver);
	Actions action = new Actions(driver);
	  Assertions assertion = new Assertions(driver);



	Testutil testUtil = new Testutil(driver);

	@When("user click on {string} under {string}")
	public void user_click_on_under_customer(String tab, String section) {
		try {
			if (!driver.findElements(By.xpath("//button[@aria-label='Discard changes']")).isEmpty())
				driver.findElement(By.xpath("//button[@aria-label='Discard changes']")).click();
			accountpage.entity(tab);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("user select {string} Assessment in Assessment form")
	public void user_select_searched_Assessment_in_Assessment_form(String contactName) {
		try {
			Log.info("parameter value is " + contactName);

			Wait.untilPageLoadComplete(driver);
			driver.findElement(By.xpath("//a[contains(@aria-label,'" + contactName + "')]")).click();
			Thread.sleep(3000);
		} catch (Exception ee) {
			System.out.println(ee);
			// ExtentCucumberAdapter.getCurrentStep().info(ee);
		}
	}

	@When("user enters the {string} details")
	public void user_enters_the_details(String string, DataTable datatable) {
		List<Map<String, String>> data = datatable.asMaps(String.class, String.class);
		List<List<String>> actual = datatable.cells();
		System.out.println(actual.size());
		try {
			action.sendKeys(Keys.TAB).build().perform();
			action.sendKeys(Keys.PAGE_DOWN).build().perform();
			for (int j = 0; j < actual.size() - 1; j++) {
				String GoalSetting = data.get(j).get("Goal Setting");
				System.out.println("Goal is : " + GoalSetting);
				testUtil.sendKeys(driver, driver.findElement(By.xpath("//input[contains(@aria-label,'"+GoalSetting+"')]")), 3, "TEST");
					
			}
		}
	catch(

	Exception ee)
	{
		System.out.println(ee);
		// ExtentCucumberAdapter.getCurrentStep().info(ee);
	}

}
	@Then("user validates {string} section in {string} are mapped from Assessment")
	public void user_validates_in_are_mapped_from_assessment(String string, String string2,DataTable datatable) {
		
		List<Map<String, String>> data = datatable.asMaps(String.class, String.class);
		List<List<String>> actual = datatable.cells();
		System.out.println(actual.size());
		try {
			action.sendKeys(Keys.TAB).build().perform();
			action.sendKeys(Keys.PAGE_DOWN).build().perform();
			for (int j = 0; j < actual.size() - 1; j++) {
				String GoalSetting = data.get(j).get("Goal Setting");
				System.out.println("Goal is : " + GoalSetting);
				assertion.CheckAssertion(driver.findElement(By.xpath("//input[contains(@aria-label,'"+GoalSetting+"')]")).getAttribute("title"), "TEST");
					
			}
		}
	catch(

	Exception ee)
	{
		System.out.println(ee);
		// ExtentCucumberAdapter.getCurrentStep().info(ee);
	}
	   
	}

	@Then("user enters Action field in {string} Quick Create form")
	public void user_enters_Action_field_in_Quick_Create_form(String string) {
		
		try {
			new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//input[@aria-label='Action']"))));

			testUtil.sendKeys(driver, driver.findElement(By.xpath("//input[@aria-label='Action']")), 3, "TEST_ACTION");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	@Then("user enters ByWhen field in {string} Quick Create form")
	public void user_enters_By_When_field_in_Quick_Create_form(String string) {
		
		try {
			new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//input[contains(@aria-describedby,'TextFieldDescription')]"))));

			testUtil.sendKeys(driver, driver.findElement(By.xpath("//input[contains(@aria-describedby,'TextFieldDescription')]")), 3, "11/08/2022");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	@Then("user validates the {string} is showing in Action Grid")
	public void user_validates_the_New_Action_is_showing_in_Action_Grid(String actionName) {
		try {
			new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//section[@aria-label='Actions']"))));

			assertion.CheckAssertionTrue(driver.findElement(By.xpath("//section[@aria-label='Actions']")).getAttribute("textContent").contains(actionName), actionName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
