package com.sat.StepDefinitions;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.sat.Pages.CasePage;
import com.sat.Pages.ContactForm;
import com.sat.testUtil.Log;
import com.sat.testUtil.Testutil;
import com.sat.testbase.TestBase;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ContactFormStepDefs {

	WebDriver driver = TestBase.getDriver();
	TestBase testbase = new TestBase();
	public ContactForm contact = new ContactForm(driver);
	Testutil testUtil = new Testutil(driver);
	private CasePage casepage = new CasePage(driver);



	@When("user search {string} and click on contact name link")
	public void cick_on_any_contact_name_link(String name) throws InterruptedException {
		try {
			contact.Clickoncontactname(name);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("verify all tabs are appearing on the Contact Form")
	public void verify_all_tabs_are_appearing_on_the_Contact_Form(DataTable datatable) {
		try {
			contact.verifyalltab(datatable);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@When("user click on {string} tab")
	public void click_on_tab(String tab) {
		try {
			Thread.sleep(2000);
			Log.info("Tab to click is : " + tab);
			contact.clickOnTab(tab);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("verify Locked and unlocked fields under section")
	public void verify_Locked_unlocked_fields_under_section(DataTable datatable) {
		try {
			contact.lockedUnlocked(datatable);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("verify Unlocked fields under GENERAL INFORMATION section")
	public void verify_Unlocked_fields_under_GENERAL_INFORMATION_section() {
	}

	@Then("verify filter options on the timeline")
	public void verify_filter_options_on_the_timeline() throws InterruptedException {
		try {
			contact.filterOfTimeline();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("click on New Emergency Contact")
	public void click_on_New_Emergency_Contact() throws InterruptedException {
		try {
			contact.clickOnNewEmergencyContact();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}

	}

	@Then("click on New Contact")
	public void click_on_New_Contact() throws InterruptedException {
		try {
			contact.clickOnNewContact();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("click on New Account")
	public void click_on_New_Account() throws InterruptedException {
		try {
			contact.clickOnNewAccount();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@And("verify all section {string} under Data Protection tab")
	public void verify_all_section_DATA_PROTECTION_DETAILS_under_Data_Protection_tab(String pageheading) {
		try {
			contact.verifyheading(pageheading);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@And("click on New Data Protection link")
	public void click_on_New_Data_Protection_link() throws InterruptedException {
		try {
			contact.clickOnNewDataProtection();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("verify all section under tab")
	public void verify_all_section_under_General_tab(DataTable dataTable) throws InterruptedException {
		try {
			contact.verifySectiOnOfTab(dataTable);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("user click on save button")
	public void user_click_on_save_button() throws InterruptedException {
		try {
			contact.clickOnSave();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("user click on save and close button")
	public void user_click_on_save_and_close_button() throws InterruptedException {
		try {
			contact.clickOnSaveAndClose();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("user click on {string}")
	public void user_click_on_(String option) throws InterruptedException {
		try {

			Log.info("Option is == "+ option);
			Thread.sleep(3000);
			contact.clickOn(option);
			Thread.sleep(3000);
			List<WebElement> li  = driver.findElements(By.xpath("//button[@aria-label='Confirm']"));
			if (li.size()!=0) 
			testUtil.clickOn(driver, driver.findElement(By.xpath("//button[@aria-label='Confirm']")), 1);
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}
	
	@Then("user click on {string} button")
	public void user_click_on_button(String option) throws InterruptedException {
		try {
			Log.info("Option is == "+ option);
			//Thread.sleep(3000);
			testUtil.clickOn(driver, driver.findElement(By.xpath("//*[text()='" + option + "']")), 10);
			//contact.clickOn(option);
			Thread.sleep(3000);
					
			
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@And("user clicks on {string}")
	public void user_clicks_on_(String option) throws InterruptedException {
		try {
			Thread.sleep(2000);
			contact.clicksOn(option);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("user click on refresh button")
	public void user_click_on_refresh_button() throws InterruptedException {
		try {
			contact.clickOnRefresh();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("User validates the text {string}")
	public void user_validates_text(String text) throws InterruptedException {
		try {
			contact.validateText(text);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("User validates the text {string} not present")
	public void user_validates_text_not_present(String text) throws InterruptedException {
		try {
			contact.validateTextNotPresent(text);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("user click on Back button")
	public void user_click_on_back_button() throws InterruptedException {
		try {
			contact.clickOnBack();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("user open {string} Form")
	public void user_open_Form(String text) throws InterruptedException {
		try {
			contact.openForm(text);
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("user click on confirm button")
	public void user_click_on_confirm_button() throws InterruptedException {
		try {
			contact.clickOnConfirm();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("user enter description")
	public void user_enter_description() {
		try {
			contact.enterDescription();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	@Then("user enters description")
	public void user_enters_description() throws Exception {
		try {
			contact.description();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

	// textarea[@aria-label='Description']
	@Then("user upload document")
	public void user_upload_document() throws InterruptedException, AWTException {
		try {
			WebElement element = driver.findElement(By.xpath("//li[text()='Related']"));
			element.click();
			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_DOWN);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(2000);
			// Actions action = new Actions(driver);
			// WebElement element= driver.findElement(By.xpath("//li[@title='Documents']"));
			// action.moveToElement().click().perform();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}

	}

	@Then("verify all tabs are appearing on the {string} Form")
	public void verify_all_tabs_are_appearing_on_the_Form(String form, DataTable datatable) {
		List<List<String>> actual = datatable.cells();
		List<WebElement> element = driver.findElements(By.xpath("//ul[@aria-label='" + form + "']/li"));
		try {
			for (int i = 0; i < 1; i++) {
				for (int j = 0; j < element.size(); j++) {
					System.out.println(element.get(j).getText());
					Assert.assertEquals(actual.get(i).get(j), element.get(j).getText(), "Element is not Displayed");
				}

			}
		} catch (Exception e) {
			System.out.println("EXception :" + e + " has occurered");
		}
	}

	@Then("user Scroll down to Account field and click on the address hyperlink")
	public void user_click_on_the_address_hyperlink_and_open_Household_Group_Form()
			throws InterruptedException, AWTException {
		try {
			contact.clickOnAccountHyperlink();
		} catch (Exception e) {
			System.out.println("Exception :" + e + " has occurred");
		}
	}

}
