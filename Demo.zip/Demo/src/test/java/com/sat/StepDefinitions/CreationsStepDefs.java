package com.sat.StepDefinitions;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.sat.Pages.Assessment_ET;
import com.sat.Pages.CasePage;
import com.sat.Pages.ContactForm;
import com.sat.Pages.Creations;
import com.sat.Pages.ETCase_ET;
import com.sat.Pages.GenericCases;
import com.sat.Pages.LoginPage;
import com.sat.Pages.Optimization;
import com.sat.Pages.Outcome_ET;
import com.sat.Pages.SLATimer;
import com.sat.testUtil.Assertions;
import com.sat.testUtil.Testutil;
import com.sat.testbase.TestBase;

import io.cucumber.java.en.Then;

public class CreationsStepDefs {
	
	TestBase testbase = new TestBase();
	WebDriver driver = TestBase.getDriver();
	LoginPage loginpage = new LoginPage(driver);
	Testutil testutil = new Testutil(driver);
	Assertions assertion = new Assertions(driver);
	Actions actions = new Actions(driver);
	Assessment_ET assessment_ET = new Assessment_ET(driver);
	SLATimer slatimer = new SLATimer(driver);
	private CasePage cases = new CasePage(driver);
	Optimization omptimization = new Optimization(driver);
	GenericCases genericCases = new GenericCases(driver);
	private ContactForm contact = new ContactForm(driver);
	HashMap<String, String> assessmentDetails = new HashMap<String, String>();
	HashMap<String, String> dates = new HashMap<String, String>();
	Outcome_ET outcome_et = new Outcome_ET(driver);
	ETCase_ET etCase_et = new ETCase_ET(driver);
	Creations creations = new Creations(driver);
	
	@Then("user navigates to {string} form")
	public void user_navigates_to_form(String string) throws Exception {
		//Thread.sleep(2000);
		
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;

		// Scrolling down the page till the element is found
		js.executeScript("arguments[0].scrollIntoView();",
				driver.findElement(By.xpath("//div[@data-lp-id='form-header-title']")));
		
		driver.findElement(By.xpath("//div[@data-id='form-selector']")).click();
		driver.findElement(By.xpath("//li[@aria-label='"+string+"']")).click();

	
	}

	
	@Then("user validates {string} section")
	public void user_validates_section(String string) throws Exception {
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;

		// Scrolling down the page till the element is found
		js.executeScript("arguments[0].scrollIntoView();",
				driver.findElement(By.xpath("//section[@aria-label='"+string+"']")));
	}
	
	@Then("user enters the address details")
	public void user_enters_the_address_details() {
		
		testutil.sendKeys(driver,driver.findElement(By.xpath("//input[@aria-label='Street 1']")) ,5, "Street1");
		testutil.sendKeys(driver,driver.findElement(By.xpath("//input[@aria-label='Street 2']")) ,5, "Street2");
		testutil.sendKeys(driver,driver.findElement(By.xpath("//input[@aria-label='Town']")) ,5, "Town");
		testutil.sendKeys(driver,driver.findElement(By.xpath("//input[@aria-label='County']")) ,5, "India");
		testutil.sendKeys(driver,driver.findElement(By.xpath("//input[@aria-label='Postcode']")) ,5, "12345");

	}
	
	@Then("user validate {string} is displayed in top ribbon")
	public void user_validate_is_displayed_on_the_form_header(String string) throws Exception {
		Thread.sleep(2000);		
		assertion.CheckAssertionTrue(driver.findElement(By.xpath("//div[@data-lp-id='form-header-title']")).getAttribute("textContent").contains(string), string);

	}
	
	@Then("user validate {string} is displayed")
	public void user_validate_is_displayed(String string) throws Exception {
		Thread.sleep(2000);		
		assertion.CheckAssertionTrue(driver.findElements(By.xpath("//h3[text()='"+string+"']")).size()!=0, string);

	}
	
	@Then("user click on {string} under CONTACTS section")
	public void user_click_on_under_CONTACTS_section(String string) {
	   
	}
}
